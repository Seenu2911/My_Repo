package com.cts.pss.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "check_in")
public class CheckIn {

	@Id
	@GeneratedValue
	private int id;
	private String seatNumber;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "bookingId")
	private BookingRecord bookingId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "passengerId")
	private Passenger passengerId;

	public CheckIn() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CheckIn(String seatNumber, BookingRecord bookingId, Passenger passengerId) {
		super();
		this.seatNumber = seatNumber;
		this.bookingId = bookingId;
		this.passengerId = passengerId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public BookingRecord getBookingId() {
		return bookingId;
	}

	public void setBookingId(BookingRecord bookingId) {
		this.bookingId = bookingId;
	}

	public Passenger getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Passenger passengerId) {
		this.passengerId = passengerId;
	}
	
	
}
