package com.cts.pss.dao.service;

import com.cts.pss.dao.UserDirectoryDao;
import com.cts.pss.entity.UserDetails;

public interface UserService extends UserDirectoryDao {

	 UserDetails findByEmail(String userName);

	 UserDetails save(UserDetails userdet);
}
