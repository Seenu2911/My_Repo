package com.cts.pss.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.pss.entity.BookingRecord;
import com.cts.pss.entity.CheckIn;
import com.cts.pss.entity.Flight;
import com.cts.pss.entity.FlightInfo;
import com.cts.pss.entity.Passenger;

public interface FlightDao extends JpaRepository<Flight, Integer>{
         
	/*
	 * List<Product> findProductByNameLike(String name); List<Product>
	 * findProductByPriceBetween(double startRange,double endRange);
	 */
	
	@Query(value = "from Flight as f where f.origin = :origin ")
	public List<Flight> findFlightsByOrigin(@Param("origin")String origin);
	
	@Query(value = "from Flight f1 inner join FlightInfo fi on fi.flightInfoid = f1.flightInfoid where fi.flightInfoid in (:info1, :info2, :info3)")
	public List<Flight> findIndigoFlights(@Param("info1")int info1, @Param("info2")int info2, @Param("info3")int info3);
	
	@Query(value = "from Flight as f inner join Fare f1 on f.fareId = f1.fareId where (f.origin = :origin or f.origin = :destination) and (f.destination = :origin or destination = :destination) order by f1.fare asc")
	public List<Flight> findDelChnFlights(@Param("origin")String origin,@Param("destination")String destination);
	
	@Query(value = "from Flight as f")
	public List<Flight> findAllFlights();
	
	@Query(value = "from Flight as f where f.flightNumber = :flightNumber")
	public List<Flight> findSingleFlight(@Param("flightNumber")String flightNum);
	
	@Query(value = "from Flight as f where f.origin = ?1 and f.destination = ?2 and f.flightDate = ?3")
public List<Flight> findAvailableFlights(String origin, String destination, LocalDate flightDate);
	
	@Query(value = "from Flight as f where f.origin = ?1 and f.destination = ?2 and f.flightDate = ?3 and f.flightTime = ?4")
	public List<Flight> findFlightsForBooking(String origin, String destination, LocalDate flightDate, LocalTime flightTime);
	
	@Query(value = "from Passenger p inner join BookingRecord b on p.bookingId.bookingId = b.bookingId where p.bookingId.bookingId = ?1")
	public List<Passenger> findBookingDetails(int bookingId);
	
	@Query(value = "from CheckIn c where c.seatNumber = ?1")
	public List<CheckIn> findCheckinDetails(String seatNum);
	
}


