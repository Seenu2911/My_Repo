package com.cts.pss.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.pss.entity.UserDetails;

@Repository
public interface UserDirectoryDao extends JpaRepository<UserDetails, String>{

	@Query("select u from UserDetails u where u.userName = ?1")
	public UserDetails findByEmail(String userName);
	
}
