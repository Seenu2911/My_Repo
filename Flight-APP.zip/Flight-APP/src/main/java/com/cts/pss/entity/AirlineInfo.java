package com.cts.pss.entity;

import java.util.List;

import java.util.ArrayList;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;

@Entity
public class AirlineInfo {

	@Id
	@GeneratedValue
	private int airlineId;
	private String airlineLogo;
	private String airlineName;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(name = "flightsInfo",
	joinColumns = {@JoinColumn(name="airlineId")},
	inverseJoinColumns = {@JoinColumn(name="flightInfoid")})
	private List<FlightInfo> info=new ArrayList<>();

	public List<FlightInfo> getInfo() {
		return info;
	}


	public void setInfo(List<FlightInfo> info) {
		this.info = info;
	}


	public AirlineInfo() {
		
	}
	
	
	public AirlineInfo(String airlineLogo, String airlineName) {
		super();
		this.airlineLogo = airlineLogo;
		this.airlineName = airlineName;
	}


	public int getAirlineId() {
		return airlineId;
	}
	public void setAirlineId(int airlineId) {
		this.airlineId = airlineId;
	}
	public String getAirlineLogo() {
		return airlineLogo;
	}
	public void setAirlineLogo(String airlineLogo) {
		this.airlineLogo = airlineLogo;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	
}
