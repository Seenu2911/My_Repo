package com.cts.pss.dao.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.cts.pss.dao.FlightDao;
import com.cts.pss.entity.BookingRecord;
import com.cts.pss.entity.CheckIn;
import com.cts.pss.entity.Flight;
import com.cts.pss.entity.FlightInfo;
import com.cts.pss.entity.Passenger;
@Service
public class FlightServiceImpl implements FlightService{

	@Autowired
    JdbcTemplate template;
	
	@Autowired
	FlightDao flightDao;
	
	@Override
	public List<Flight> findAll() {
		// TODO Auto-generated method stub
			return flightDao.findAll();
	}

	@Override
	public List<Flight> findFlightsByOrigin(String origin) {
		// TODO Auto-generated method stub
		return flightDao.findFlightsByOrigin(origin);
	}

	@Override
	public List<Flight> findIndigoFlights(int info1, int info2, int info3) {
		// TODO Auto-generated method stub
		return flightDao.findIndigoFlights(info1, info2, info3);
	}

	@Override
	public List<Flight> findDelChnFlights(String origin, String destination) {
		// TODO Auto-generated method stub
		return flightDao.findDelChnFlights(origin, destination);
	}

	@Override
	public List<Flight> findAllFlights() {
		// TODO Auto-generated method stub
		return flightDao.findAllFlights();
	}

	@Override
	public List<Flight> findSingleFlight(String flightNum) {
		// TODO Auto-generated method stub
		return flightDao.findSingleFlight(flightNum);
	}

	@Override
	public List<Flight> findAvailableFlights(String origin, String destination, LocalDate flightDate) {
		// TODO Auto-generated method stub
		return flightDao.findAvailableFlights(origin, destination, flightDate);
	}

	@Override
	public List<Flight> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> findAllById(Iterable<Integer> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Flight> S saveAndFlush(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteInBatch(Iterable<Flight> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight getOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Flight> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Flight> findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Flight entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends Flight> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Flight> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Flight> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Flight> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Flight> findFlightsForBooking(String origin, String destination, LocalDate flightDate,
			LocalTime flightTime) {
		// TODO Auto-generated method stub
		return flightDao.findFlightsForBooking(origin, destination, flightDate, flightTime);
		
	}

	@Override
	public List<Passenger> findBookingDetails(int bookingId) {
		// TODO Auto-generated method stub
		return flightDao.findBookingDetails(bookingId);
	}

	@Override
	public List<CheckIn> findCheckinDetails(String seatNum) {
		// TODO Auto-generated method stub
		return flightDao.findCheckinDetails(seatNum);
	}

	

}
