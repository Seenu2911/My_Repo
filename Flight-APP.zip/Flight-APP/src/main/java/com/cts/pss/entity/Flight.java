package com.cts.pss.entity;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
public class Flight {

	@Id
	@GeneratedValue
	private int id;
	private String destination;
	private String duration;
	private LocalDate flightDate;
	private String flightNumber;
	private LocalTime flightTime;
	private String origin;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "fareId")
	private Fare fareId;
	
	@OneToOne(fetch = FetchType.EAGER,
	        cascade = {
	                CascadeType.MERGE,
	                CascadeType.REFRESH
	            })
	@JoinColumn(name = "flightInfoId")
	private FlightInfo flightInfoid;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "inventoryId")
	private Inventory inventoryId;

	
	public Flight() {
		// TODO Auto-generated constructor stub
	}

	
	public Flight(String flightNumber, String destination, String origin, String duration, LocalDate flightDate, LocalTime flightTime,
			Fare fareId, FlightInfo flightInfoid, Inventory inventoryId) {
		super();
		this.destination = destination;
		this.duration = duration;
		this.flightDate = flightDate;
		this.flightNumber = flightNumber;
		this.flightTime = flightTime;
		this.origin = origin;
		this.fareId = fareId;
		this.flightInfoid = flightInfoid;
		this.inventoryId = inventoryId;
	}


	public Flight(String origin, String destination, String flightNumber, Date flightDate, Time flightTime, String duration) {
		// TODO Auto-generated constructor stub
		this.origin = origin;
		this.destination = destination;
		this.flightNumber = flightNumber;
		this.flightDate = flightDate.toLocalDate();
		this.flightTime = flightTime.toLocalTime();
		this.duration = duration;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public LocalDate getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(LocalDate flightDate) {
		this.flightDate = flightDate;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public LocalTime getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(LocalTime flightTime) {
		this.flightTime = flightTime;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public Fare getFareId() {
		return fareId;
	}

	public void setFareId(Fare fareId) {
		this.fareId = fareId;
	}

	public FlightInfo getFlightInfoid() {
		return flightInfoid;
	}


	public void setFlightInfoid(FlightInfo flightInfoid) {
		this.flightInfoid = flightInfoid;
	}


	public Inventory getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(Inventory inventoryId) {
		this.inventoryId = inventoryId;
	}

	
	

	
}
