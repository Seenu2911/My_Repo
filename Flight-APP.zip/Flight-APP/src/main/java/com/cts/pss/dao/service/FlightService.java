package com.cts.pss.dao.service;

import java.util.List;

import com.cts.pss.dao.FlightDao;
import com.cts.pss.entity.Flight;

public interface FlightService extends FlightDao{

	//List<Flight> findAll();
}
