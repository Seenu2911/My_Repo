package com.cts.pss.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.pss.dao.BookFlightDao;
import com.cts.pss.dao.CheckInDao;
import com.cts.pss.dao.FlightDao;
import com.cts.pss.dao.PassengerDao;
import com.cts.pss.dao.UserDirectoryDao;
import com.cts.pss.dao.service.FlightServiceImpl;
import com.cts.pss.entity.BookingRecord;
import com.cts.pss.entity.CheckIn;
import com.cts.pss.entity.Flight;
import com.cts.pss.entity.Passenger;
import com.cts.pss.entity.UserDetails;

@Controller
public class FlightController {

	@Autowired
	UserDirectoryDao uDao;
	
	@Autowired
	BookFlightDao bookDao;
	@Autowired
	PassengerDao passDao;
	@Autowired
	CheckInDao checkDao;
	@Autowired
	FlightServiceImpl fService;
	
	@ModelAttribute("user")
	
	@RequestMapping(value = "/home")
	public String f1(Model data) {
		return "loginPage";
	}
	
	@RequestMapping(value = "/register")
	public String f2(Model data) {
		//data.addAttribute("user", "Praveen");
		return "registration";
	}
	
	@RequestMapping(value = "/searchFlights")
	public String searchFlights(Model data) {
		return "searchFlights";
	}
	
	 @RequestMapping(value = "/search")
	    public String findFlights(@RequestParam(value="origin") String origin, 
	    		@RequestParam(value="destination") String destination, 
	    		@RequestParam(value="flightDate") String flightDate, Model md){
		 
		 Date fDate = Date.valueOf(flightDate);   
		 List<Flight> flight = fService.findAvailableFlights(origin, destination, fDate.toLocalDate());
	        md.addAttribute("flights", flight);

	        //return new ResponseEntity<List<Flight>>(flight, HttpStatus.OK);
	        return "flightResult";
	    }
	
	 @RequestMapping(value="/bookFlight")
	 public String showBookingPage() {
		 return "passengerDetails";
	 }
	 
	 @RequestMapping(value="/confirmBooking", method=RequestMethod.POST)
	 public String confirmBooking(@RequestParam(value="flightNum") String flightNum,
			 @RequestParam(value="firstName") String firstName, @RequestParam(value="lastName") String lastName,
			 @RequestParam(value="phno") String phoneNum, @RequestParam(value="gender") String gender,
			 @RequestParam(value="emailId") String emailId,Model md) {
		 
		 List<Flight> flights = fService.findSingleFlight(flightNum);
		 List<BookingRecord> booking = new ArrayList<BookingRecord>();
		 List<Passenger> pass = new ArrayList<Passenger>();
		 
		 for(Flight fl : flights) {
			 if(fl.getInventoryId().getCount() != 0) {
				BookingRecord b1  = new BookingRecord(LocalDate.now(), 
						 fl.getDestination(), fl.getFareId().getFare(), fl.getFlightDate(), fl.getFlightNumber(), fl.getFlightTime(), fl.getOrigin(), "Confirmed");
					Passenger p1 = new Passenger(emailId, firstName, gender, lastName,
					  phoneNum, b1); 
					b1.getInfo().add(p1);
					booking.add(b1);
					pass.add(p1);
					bookDao.save(b1);
					passDao.save(p1);
					fl.getInventoryId().setCount(fl.getInventoryId().getCount()-1);
					fService.save(fl);
			 }
		 }
		 md.addAttribute("bookingRec", booking);
		 md.addAttribute("passengers",pass);
		 return "success";
	 }
	
	 @RequestMapping(value = "/checkin")
		public String checkin(@RequestParam(value="bookingId") String bookingId, Model md) {
		
		 int bId = Integer.valueOf(bookingId);
		 List<Passenger> passDet = fService.findBookingDetails(bId);
		 
		 List<CheckIn> checkinList = new ArrayList<CheckIn>();
		 int passId = 0;
		 for(Passenger pass : passDet) {
			 
			 String flightNum = pass.getBookingId().getFlightNumber();
			 int bookId = pass.getBookingId().getBookingId();
			 passId = pass.getPassengerId();
			 String seatNum = (flightNum.substring(0, 2)).concat(String.valueOf(bookId));
			 checkinList = fService.findCheckinDetails(seatNum);
			 if(checkinList.size() == 0) {
			 CheckIn c1 = new CheckIn(seatNum, pass.getBookingId(), pass);
			 checkinList.add(c1);
			 
			 checkDao.save(c1);
			 md.addAttribute("seatNum", seatNum);
			 }
			 else {
				 md.addAttribute("error","Booking Id already Checked in!!");
			 }
		 }
		 
		 md.addAttribute("passengers",passDet);
			return "checkinSuccess";
		}
	 
	 @RequestMapping(value = "/checkinPage")
	 public String showCheckinPage() {
		 return "checkin";
	 }
}
