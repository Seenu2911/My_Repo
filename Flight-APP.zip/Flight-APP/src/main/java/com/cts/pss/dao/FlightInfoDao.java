package com.cts.pss.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.pss.entity.FlightInfo;

public interface FlightInfoDao extends JpaRepository<FlightInfo, Integer>{

	/*@Query("SELECT new com.cts.pss.entity.FlightInfo(f.flight_infoid)"
	        + "FROM flight_info f")
	 Integer findByFlightName(String flightName);*/
}
