package com.cts.pss.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.pss.entity.AirlineInfo;

public interface AirlineDao extends JpaRepository<AirlineInfo, Integer>{

}
