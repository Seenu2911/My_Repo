package com.cts.pss;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cts.pss.controller.FlightController;
import com.cts.pss.dao.AirlineDao;
import com.cts.pss.dao.BookFlightDao;
import com.cts.pss.dao.FlightDao;
import com.cts.pss.dao.FlightInfoDao;
import com.cts.pss.dao.PassengerDao;
import com.cts.pss.dao.service.FlightServiceImpl;
import com.cts.pss.entity.AirlineInfo;
import com.cts.pss.entity.BookingRecord;
import com.cts.pss.entity.Fare;
import com.cts.pss.entity.Flight;
import com.cts.pss.entity.FlightInfo;
import com.cts.pss.entity.Inventory;
import com.cts.pss.entity.Passenger;

@SpringBootApplication
public class FlightAppApplication{
	
	
	public static void main(String[] args) {
		ApplicationContext appCon = 
				SpringApplication.run(FlightAppApplication.class, args);
		
		/*AirlineDao airDao = appCon.getBean(AirlineDao.class);
		FlightDao flight = appCon.getBean(FlightDao.class);
		//PassengerDao passengers = appCon.getBean(PassengerDao.class);
		//BookFlightDao book = appCon.getBean(BookFlightDao.class);
		
		//List<Flight> flights = new ArrayList<Flight>();
		List<AirlineInfo> airlines = new ArrayList<>();
		//List<BookingRecord> booking = new ArrayList<BookingRecord>();
		//List<Passenger> pass = new ArrayList<Passenger>();
		List<Flight> flightQuery=flight.findFlightsByOrigin("DELHI");
		//List<Flight> flights=flight.findIndigoFlights(6,7,8);
		//List<Flight> flights=flight.findDelChnFlights("Chennai", "Delhi");
		//List<FlightInfo> flightsInfo = flight.findSingleFlight("6E-6686");
		
		//List<Flight> flightQuery = flight.findAvailableFlights("DELHI", "HYDERABAD", LocalDate.of(2020, 8, 21), LocalTime.of(01, 15));
		for (Flight fl : flightQuery) {
			System.out.print("[");
			System.out.print("Origin: "+fl.getOrigin()+";");
			System.out.print("Number: "+fl.getFlightNumber()+";");
			System.out.print("Destination: "+fl.getDestination()+";");
			System.out.print("Date: "+fl.getFlightDate()+";");
			System.out.print("Time: "+fl.getFlightTime()+";");
			System.out.print("Fare: "+fl.getFareId().getFare()+";");
			System.out.print("No. of Passengers: "+fl.getInventoryId().getCount()+";");
			System.out.print("]");
			System.out.println();
			
			
		}
		//FlightInfo f1 = new FlightInfo("AI-250", "Airbus", 150);
		
		  AirlineInfo air1 = new AirlineInfo("airline.png","Air India"); AirlineInfo
				  air2 = new AirlineInfo("indigo.png","Indigo"); AirlineInfo air3 = new
				  AirlineInfo("air-asia.png","Air Asia"); AirlineInfo air4 = new
				  AirlineInfo("spicejet.png","Spicejet"); AirlineInfo air5 = new
				  AirlineInfo("vistara.png","Vistara"); AirlineInfo air6 = new
				  AirlineInfo("truejet.png","TruJet"); AirlineInfo air7 = new
				  AirlineInfo("goair.png","Go Air");
				  
				  airlines.add(air1); airlines.add(air2); airlines.add(air3);
				  airlines.add(air4); airlines.add(air5); airlines.add(air6);
				  airlines.add(air7);
				  
				  FlightInfo f1 = new FlightInfo("AI-840", "Airbus", 150); FlightInfo f2 = new
				  FlightInfo("AI-240", "Airbus", 150); FlightInfo f3 = new FlightInfo("AI-242",
				  "Airbus", 150);
				  
				  FlightInfo f4 = new FlightInfo("IN-560", "Airbus", 150); FlightInfo f5 = new
				  FlightInfo("IN-563", "Airbus", 150); FlightInfo f6 = new FlightInfo("IN-565",
				  "Airbus", 150);
				  
				  FlightInfo f7 = new FlightInfo("AA-344", "Airbus", 150); FlightInfo f8 = new
				  FlightInfo("AA-345", "Airbus", 150); FlightInfo f9 = new FlightInfo("AA-356",
				  "Airbus", 150);
				  
				  FlightInfo f10 = new FlightInfo("SJ-575", "Airbus", 150); FlightInfo f11 =
				  new FlightInfo("SJ-578", "Airbus", 150); FlightInfo f12 = new
				  FlightInfo("SJ-579", "Airbus", 150);
				  
				  FlightInfo f13 = new FlightInfo("UK-832", "Airbus", 150); FlightInfo f14 =
				  new FlightInfo("UK-833", "Airbus", 150); FlightInfo f15 = new
				  FlightInfo("UK-840", "Airbus", 150);
				  
				  FlightInfo f16 = new FlightInfo("TJ-220", "Airbus", 150); FlightInfo f17 =
				  new FlightInfo("TJ-223", "Airbus", 150); FlightInfo f18 = new
				  FlightInfo("TJ-225", "Airbus", 150);
				  
				  FlightInfo f19 = new FlightInfo("G8-550", "Airbus", 150); FlightInfo f20 =
				  new FlightInfo("G8-553", "Airbus", 150); FlightInfo f21 = new
				  FlightInfo("G8-560", "Airbus", 150);
				  FlightInfo f22 = new FlightInfo("IN-230",
				  "Airbus", 150);
				  FlightInfo f23 = new FlightInfo("AI-590",
				  "Airbus", 150);
				  FlightInfo f24 = new FlightInfo("AI-600","Airbus", 150);
				  FlightInfo f25 = new FlightInfo("UK-590","Airbus", 150);
				  FlightInfo f26 = new FlightInfo("IN-6678","Airbus", 150);
				  FlightInfo f27 = new FlightInfo("AA-1290","Airbus", 150);
				  FlightInfo f28 = new FlightInfo("6E-6686","Airbus", 150);
				  FlightInfo f29 = new FlightInfo("TJ-277","Airbus", 150);
				  FlightInfo f30 = new FlightInfo("AI-9088","Airbus", 150);
				  FlightInfo f31 = new FlightInfo("UK-1590","Airbus", 150);
				  FlightInfo f32 = new FlightInfo("G8-500","Airbus", 150);
				  FlightInfo f33 = new FlightInfo("SJ-5190","Airbus", 150);
				  
				  air1.getInfo().add(f1); air1.getInfo().add(f2); air1.getInfo().add(f3);
				  air1.getInfo().add(f23); air1.getInfo().add(f24); air1.getInfo().add(f30);
				  air2.getInfo().add(f4); air2.getInfo().add(f5); air2.getInfo().add(f6);
				  air2.getInfo().add(f22);air2.getInfo().add(f26);air2.getInfo().add(f28);
				  
				  air3.getInfo().add(f7); air3.getInfo().add(f8); air3.getInfo().add(f9);
				  air3.getInfo().add(f27);
				  air4.getInfo().add(f10); air4.getInfo().add(f11); air4.getInfo().add(f12);
				  air4.getInfo().add(f33);
				  air5.getInfo().add(f13); air5.getInfo().add(f14); air5.getInfo().add(f15);
				  air5.getInfo().add(f25); air5.getInfo().add(f31);
				  air6.getInfo().add(f16); air6.getInfo().add(f17); air6.getInfo().add(f18);
				  air6.getInfo().add(f29);
				  
				  air7.getInfo().add(f19); air7.getInfo().add(f20); air7.getInfo().add(f21);
				  air7.getInfo().add(f32);
				  airDao.saveAll(airlines);
				  
				  Flight fl1 = new Flight(f1.getFlightNumber(),"HYDERABAD",
				  "CHENNAI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(2, 12),new
				  Fare("INR",4500),f1,new Inventory(150)); Flight fl2 = new
				  Flight(f2.getFlightNumber(),"CHENNAI",
				  "DELHI","2 hours 45 mins",LocalDate.of(2020,8,21),LocalTime.of(12, 30),new
				  Fare("INR",5400),f2,new Inventory(150)); Flight fl3 = new
				  Flight(f13.getFlightNumber(),"DELHI",
				  "CHENNAI","3 hours 20 mins",LocalDate.of(2020,8,21),LocalTime.of(13, 45),new
				  Fare("INR",2500),f13,new Inventory(150)); Flight fl4 = new
				  Flight(f4.getFlightNumber(),"HYDERABAD",
				  "PUNE","2 hours 50 mins",LocalDate.of(2020,8,21),LocalTime.of(21, 12),new
				  Fare("INR",3380),f4,new Inventory(150)); Flight fl5 = new
				  Flight(f15.getFlightNumber(),"HYDERABAD",
				  "MUMBAI","5 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(5, 0),new
				  Fare("INR",5600),f15,new Inventory(150)); Flight fl6 = new
				  Flight(f6.getFlightNumber(),"BENGALURU",
				  "CHENNAI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(12, 34),new
				  Fare("INR",3450),f6,new Inventory(150)); Flight fl7 = new
				  Flight(f7.getFlightNumber(),"VIZAG",
				  "CHENNAI","4 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(20, 50),new
				  Fare("INR",4550),f7,new Inventory(150)); Flight fl8 = new
				  Flight(f8.getFlightNumber(),"CHENNAI",
				  "VIZAG","4 hours 45 mins",LocalDate.of(2020,8,21),LocalTime.of(21, 50),new
				  Fare("INR",4850),f8,new Inventory(150)); Flight fl9 = new
				  Flight(f9.getFlightNumber(),"HYDERABAD",
				  "CHENNAI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(4, 12),new
				  Fare("INR",7760),f9,new Inventory(150)); Flight fl10 = new
				  Flight(f10.getFlightNumber(),"CHENNAI",
				  "MUMBAI","2 hours 25 mins",LocalDate.of(2020,8,21),LocalTime.of(3, 22),new
				  Fare("INR",4530),f10,new Inventory(150)); Flight fl11 = new
				  Flight(f12.getFlightNumber(),"BENGALURU",
				  "HYDERABAD","6 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(15,
				  15),new Fare("INR",13550),f12,new Inventory(150)); Flight fl12 = new
				  Flight(f13.getFlightNumber(),"BENGALURU",
				  "HYDERABAD","3 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(6, 15),new
				  Fare("INR",3350),f13,new Inventory(150)); Flight fl13 = new
				  Flight(f21.getFlightNumber(),"HYDERABAD",
				  "CHENNAI","4 hours 10 mins",LocalDate.of(2020,8,21),LocalTime.of(5, 12),new
				  Fare("INR",10000),f21,new Inventory(150)); Flight fl14 = new
				  Flight(f20.getFlightNumber(),"CHENNAI",
				  "MANGALORE","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(3, 12),new
				  Fare("INR",5500),f20,new Inventory(150)); Flight fl15 = new
				  Flight(f5.getFlightNumber(),"MUMBAI",
				  "DELHI","4 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(21, 12),new
				  Fare("INR",4500),f5,new Inventory(150));
				  Flight fl16 = new  Flight(f22.getFlightNumber(),"HYDERABAD",
				  "DELHI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(01, 15),new
				  Fare("INR",3200),f22,new Inventory(100)); 
				  Flight fl17 = new  Flight(f23.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(01, 15),new
				  Fare("INR",3200),f23,new Inventory(100)); 
Flight fl18 = new  Flight(f26.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(15, 30),new
				  Fare("INR",3500),f26,new Inventory(100)); 
Flight fl19 = new  Flight(f29.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(12, 30),new
				  Fare("INR",2800),f29,new Inventory(100)); 
Flight fl20 = new  Flight(f30.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(17, 20),new
				  Fare("INR",3200),f30,new Inventory(100)); 
Flight fl21 = new  Flight(f31.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(8, 15),new
				  Fare("INR",3200),f31,new Inventory(100)); 
Flight fl22 = new  Flight(f32.getFlightNumber(),"CHENNAI",
				  "PUNE","4 hours 15 mins",LocalDate.of(2020,8,22),LocalTime.of(10, 50),new
				  Fare("INR",3200),f32,new Inventory(100)); 
Flight fl23 = new  Flight(f24.getFlightNumber(),"PUNE",
				  "DELHI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(10, 50),new
				  Fare("INR",3500),f24,new Inventory(100)); 
Flight fl24 = new  Flight(f25.getFlightNumber(),"PUNE",
				  "DELHI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(16, 30),new
				  Fare("INR",3200),f25,new Inventory(100)); 
Flight fl25 = new  Flight(f27.getFlightNumber(),"PUNE",
				  "DELHI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(01, 20),new
				  Fare("INR",3200),f27,new Inventory(100));
Flight fl26 = new  Flight(f28.getFlightNumber(),"PUNE",
				  "DELHI","2 hours 15 mins",LocalDate.of(2020,8,21),LocalTime.of(03, 15),new
				  Fare("INR",3000),f28,new Inventory(100));

	flight.saveAll(Arrays.asList(fl1,fl2,fl3,fl4,fl5,fl6,fl7,fl8,fl9,fl10,fl11,
				  fl12,fl13,fl14,fl15,fl16,fl17,fl18,fl19,fl20,fl21,fl22,fl23,fl24,fl25,fl26));*/
		}

}
