package com.cts.pss.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class FlightInfo {

	@Id
	@GeneratedValue
	private int flightInfoid;
	
	private String flightNumber;
	
	private String flightType;
	private int numberOfSeats;
	
	public FlightInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public FlightInfo(String flightNumber, String flightType, int numberOfSeats) {
		super();
		this.flightNumber = flightNumber;
		this.flightType = flightType;
		this.numberOfSeats = numberOfSeats;
	}


	public int getFlightInfoid() {
		return flightInfoid;
	}
	public void setFlightInfoid(int flightInfoid) {
		this.flightInfoid = flightInfoid;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightType() {
		return flightType;
	}
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	
}
