package com.cts.pss.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.pss.entity.BookingRecord;
import com.cts.pss.entity.Flight;

public interface BookFlightDao extends JpaRepository<BookingRecord, Integer> {

	
}
