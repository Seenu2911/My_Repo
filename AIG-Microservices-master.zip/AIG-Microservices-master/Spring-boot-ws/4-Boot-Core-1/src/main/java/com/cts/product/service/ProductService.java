package com.cts.product.service;

public interface ProductService {

	void listAll();

}