package com.cts.product.dao;

public interface ProductDao {

	void listAll();

}