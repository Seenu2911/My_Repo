package com.cts.product;

import org.springframework.stereotype.Component;

@Component
public class Employee {

	public Employee() {
		System.out.println("--- Employee class object created...");
	}

}
