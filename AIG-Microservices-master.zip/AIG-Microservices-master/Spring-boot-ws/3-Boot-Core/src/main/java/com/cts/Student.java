package com.cts;

import org.springframework.stereotype.Component;

@Component
public class Student {

	public Student() {
		System.out.println("====> Student class object created");
	}

}
