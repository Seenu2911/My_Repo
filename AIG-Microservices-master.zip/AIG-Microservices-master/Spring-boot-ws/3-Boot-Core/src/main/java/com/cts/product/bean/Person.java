package com.cts.product.bean;

import org.springframework.stereotype.Component;

@Component
public class Person {

	public Person() {
		System.out.println("====> Person class object created...");
	}

}
