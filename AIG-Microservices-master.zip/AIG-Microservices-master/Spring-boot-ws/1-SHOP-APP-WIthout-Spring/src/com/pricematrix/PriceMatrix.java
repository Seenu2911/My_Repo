package com.pricematrix;

public interface PriceMatrix {

	double getItemPrice(String itemCode);

}