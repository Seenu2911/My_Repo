package com.cts.entity;

public class Flight {

}
